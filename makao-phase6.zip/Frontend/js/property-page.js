/* =====================================================================
   Frontend/js/property-page.js — Makao Phase 6
   Loaded AFTER the inline script in listing.html. It:
     - adapts the real API shape (property/listing split) to the page
     - adds the "Makao intelligence" panel (match, cost, commute, freshness)
     - wires Save / Share / Call / WhatsApp / Message / Request viewing
     - removes hard-coded claims and demo data
   Nothing here is payment-gated. Estimates are always labelled as estimates.
   ===================================================================== */
(function () {
  'use strict';

  const API = '/api';
  const TOKEN_KEY = 'access_token';
  const PREFS_KEY = 'makao_prefs';

  /* ── helpers ─────────────────────────────────────────────────────── */
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const kes = (n) => 'KSh ' + Number(n || 0).toLocaleString('en-KE');
  const token = () => localStorage.getItem(TOKEN_KEY);
  const toast = (m) => (typeof window.showToast === 'function' ? window.showToast(m) : alert(m));

  function errText(d) {
    if (!d) return '';
    if (typeof d.detail === 'string') return d.detail;
    if (Array.isArray(d.detail)) return d.detail.map((x) => x.msg).join(' ');
    return '';
  }

  async function api(path, opts) {
    opts = opts || {};
    const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    const t = token();
    if (t) headers.Authorization = 'Bearer ' + t;
    const res = await fetch(API + path, Object.assign({}, opts, { headers }));
    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) {
      const err = new Error(errText(data) || 'Something went wrong (' + res.status + ').');
      err.status = res.status;
      throw err;
    }
    return data;
  }

  const Prefs = {
    get() { try { return JSON.parse(localStorage.getItem(PREFS_KEY) || 'null'); } catch (e) { return null; } },
    set(p) { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); },
    clear() { localStorage.removeItem(PREFS_KEY); },
  };
  window.MakaoPrefs = Prefs;

  /* ── state ───────────────────────────────────────────────────────── */
  let raw = null;            // API listing payload
  let propertyId = null;
  let saved = false;
  let intel = null;          // optional Phase 4 block from GET /listings/{id}
  let afterAuth = null;

  /* ── adapter: API shape -> legacy page fields ────────────────────── */
  const AMENITY_MAP = {
    backup_power: 'generator', solar_power: 'generator', swimming_pool: 'pool',
    elevator: 'lift', servant_quarter: 'dsq', air_conditioning: 'aircon',
    pet_friendly: 'pets', fibre: 'wifi',
  };
  const prettyType = (t) => (t || '').replace(/_/g, ' ').replace('4plus', '4+')
    .replace(/\b\w/g, (c) => c.toUpperCase());

  function adapt(d) {
    const p = d.property || {};
    const loc = p.location || {};
    const am = (p.amenities || []).map((a) => AMENITY_MAP[a] || a);
    const avail = d.latest_availability;
    return {
      id: d.id, title: p.title, description: p.description,
      bedrooms: p.bedrooms, bathrooms: p.bathrooms, size_sqft: p.size_sqft, floor: p.floor,
      house_type: prettyType(p.property_type), photos: p.photos || [], amenities: am,
      location: loc.neighbourhood || loc.estate || loc.ward || '',
      city: loc.subcounty || loc.ward || '', county: loc.county || '',
      latitude: loc.latitude, longitude: loc.longitude,
      price_per_month: d.asking_price, host_name: d.host_name,
      created_at: d.created_at,
      is_available: d.status === 'active' && !(avail && avail.status === 'unavailable'),
    };
  }

  const places = (l) => [l.location, l.city, l.county].filter(Boolean)
    .filter((v, i, a) => a.indexOf(v) === i).join(', ');

  function freshness(d) {
    const a = d.latest_availability;
    const st = a && a.status;
    const at = (a && a.confirmed_at) || d.last_confirmed_at;
    if (st === 'unavailable') return { text: 'Marked unavailable', tone: 'bad' };
    if (st !== 'available' || !at) return { text: 'Availability not confirmed', tone: 'warn' };
    const days = (Date.now() - new Date(at).getTime()) / 86400000;
    if (days <= 1) return { text: 'Available — confirmed today', tone: 'good' };
    if (days <= 14) return { text: 'Available — confirmed ' + Math.floor(days) + ' days ago', tone: days <= 7 ? 'good' : 'warn' };
    return { text: 'Availability last confirmed ' + Math.floor(days) + ' days ago — may be out of date', tone: 'warn' };
  }

  const VERIFY = {
    verified: 'Verified host', partially_verified: 'Partially verified host', unverified: 'Not yet verified',
  };

  /* ── styles ──────────────────────────────────────────────────────── */
  function injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
      .mk-intel{background:var(--off-white);border:1.5px solid var(--border);border-radius:var(--radius);padding:22px;}
      .mk-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:14px 0;}
      .mk-stat{background:#fff;border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 14px;}
      .mk-stat b{display:block;font-size:12px;font-weight:500;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px;}
      .mk-stat span{font-size:15px;font-weight:600;color:var(--dark);}
      .mk-stat small{display:block;font-size:12px;color:var(--muted);margin-top:3px;line-height:1.4;}
      .mk-good{color:var(--green)!important}.mk-warn{color:#b26a00!important}.mk-bad{color:#c0392b!important}
      .mk-score{display:flex;align-items:center;gap:16px;margin:6px 0 14px;}
      .mk-score-num{font-family:var(--font-display);font-size:54px;line-height:1;color:var(--accent);}
      .mk-bars{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px 16px;margin-bottom:14px;}
      .mk-bar{font-size:12px;color:var(--mid)}.mk-bar i{display:block;height:6px;border-radius:3px;background:var(--border);margin-top:3px;overflow:hidden}
      .mk-bar i em{display:block;height:100%;background:var(--accent)}
      .mk-list{margin:6px 0 12px 18px;font-size:14px;color:var(--mid);line-height:1.6}
      .mk-h{font-size:13px;font-weight:600;color:var(--dark);margin-top:10px}
      .mk-note{font-size:12px;color:var(--muted);margin-top:8px;line-height:1.5}
      .mk-ask textarea{width:100%;min-height:74px;border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;font:inherit;font-size:14px;resize:vertical}
      .mk-btn{background:var(--accent);color:#fff;border:0;border-radius:var(--radius-sm);padding:10px 16px;font:inherit;font-weight:600;cursor:pointer;margin-top:8px}
      .mk-btn:disabled{opacity:.6;cursor:default}
      .mk-link{background:none;border:0;color:var(--accent);cursor:pointer;font:inherit;font-size:12px;padding:0;text-decoration:underline}
      .mk-actions{display:flex;flex-direction:column;gap:10px}.mk-two{display:grid;grid-template-columns:1fr 1fr;gap:10px}
      .mk-spons{display:inline-block;font-size:11px;font-weight:600;border:1px solid var(--border);border-radius:50px;padding:2px 9px;color:var(--mid);margin-left:6px}
      .mk-tabs{display:flex;gap:8px;margin-bottom:14px}.mk-tabs button{flex:1;padding:9px;border:1.5px solid var(--border);background:#fff;border-radius:var(--radius-sm);font:inherit;cursor:pointer}
      .mk-tabs button.on{border-color:var(--accent);color:var(--accent);font-weight:600}
      .mk-err{color:#c0392b;font-size:13px;min-height:18px;margin:6px 0}
    `;
    document.head.appendChild(s);
  }

  /* ── modals (reuse the page's .modal-overlay / .modal-box styles) ── */
  function modal(id, inner) {
    let m = $(id);
    if (!m) {
      m = document.createElement('div');
      m.className = 'modal-overlay'; m.id = id; m.setAttribute('role', 'dialog');
      m.addEventListener('click', (e) => { if (e.target === m) closeModal(id); });
      document.body.appendChild(m);
    }
    m.innerHTML = '<div class="modal-box"><button class="modal-close-btn" aria-label="Close" ' +
      'onclick="MakaoPage.closeModal(\'' + id + '\')">✕</button>' + inner + '</div>';
    return m;
  }
  const openModal = (id) => { $(id).classList.add('open'); document.body.style.overflow = 'hidden'; };
  function closeModal(id) { const m = $(id); if (m) m.classList.remove('open'); document.body.style.overflow = ''; }

  function openAuth(next) {
    afterAuth = next || null;
    modal('mkAuth',
      '<h2 class="modal-title">Log in to continue</h2>' +
      '<p class="modal-sub">A free renter account lets you save homes and request viewings.</p>' +
      '<div class="mk-tabs"><button id="mkTabIn" class="on">Log in</button><button id="mkTabUp">Create account</button></div>' +
      '<div id="mkAuthUp" style="display:none">' +
        '<div class="form-group"><label>Full name</label><input id="mkName" autocomplete="name"></div>' +
        '<div class="form-group"><label>Phone</label><input id="mkPhone" type="tel" placeholder="07XX XXX XXX" autocomplete="tel"></div>' +
      '</div>' +
      '<div class="form-group"><label>Email</label><input id="mkEmail" type="email" autocomplete="email"></div>' +
      '<div class="form-group"><label>Password</label><input id="mkPass" type="password" autocomplete="current-password"></div>' +
      '<div class="mk-err" id="mkAuthErr"></div>' +
      '<button class="form-submit" id="mkAuthGo">Log in</button>');
    let signup = false;
    const setMode = (up) => {
      signup = up;
      $('mkAuthUp').style.display = up ? 'block' : 'none';
      $('mkTabIn').classList.toggle('on', !up); $('mkTabUp').classList.toggle('on', up);
      $('mkAuthGo').textContent = up ? 'Create account' : 'Log in';
    };
    $('mkTabIn').onclick = () => setMode(false);
    $('mkTabUp').onclick = () => setMode(true);
    $('mkAuthGo').onclick = async () => {
      const btn = $('mkAuthGo'); $('mkAuthErr').textContent = ''; btn.disabled = true;
      try {
        const body = { email: $('mkEmail').value.trim(), password: $('mkPass').value };
        if (signup) { body.full_name = $('mkName').value.trim(); body.phone = $('mkPhone').value.trim(); }
        const data = await api(signup ? '/renter/signup' : '/renter/login', { method: 'POST', body: JSON.stringify(body) });
        localStorage.setItem(TOKEN_KEY, data.access_token);
        closeModal('mkAuth');
        toast('✓ Signed in');
        await refreshSaved();
        if (afterAuth) { const f = afterAuth; afterAuth = null; f(); }
      } catch (e) { $('mkAuthErr').textContent = e.message; }
      btn.disabled = false;
    };
    openModal('mkAuth');
  }

  const needAuth = (fn) => { if (!token()) openAuth(fn); else fn(); };

  /* ── actions ─────────────────────────────────────────────────────── */
  async function refreshSaved() {
    if (!token() || !propertyId) return;
    try {
      const favs = await api('/favorites');
      saved = favs.some((f) => f.property_id === propertyId);
      paintSaved();
    } catch (e) { /* stay logged-out-looking; harmless */ }
  }

  function paintSaved() {
    const b = $('saveBtn'); if (!b) return;
    b.classList.toggle('active', saved);
    $('saveBtnLabel').textContent = saved ? 'Saved' : 'Save';
  }

  function toggleSave() {
    needAuth(async () => {
      try {
        if (saved) { await api('/favorites/' + propertyId, { method: 'DELETE' }); saved = false; toast('Removed from saved'); }
        else { await api('/favorites', { method: 'POST', body: JSON.stringify({ property_id: propertyId }) }); saved = true; toast('♥ Saved to your list'); }
        paintSaved();
      } catch (e) { toast(e.message); }
    });
  }

  async function share() {
    try {
      const s = await api('/listings/' + raw.id + '/share');
      if (navigator.share) { navigator.share({ title: raw.property.title, text: s.text, url: s.url }).catch(() => {}); }
      else { window.open(s.whatsapp_url, '_blank', 'noopener'); }
    } catch (e) { toast(e.message); }
  }

  async function contactChannel(channel) {
    const tab = channel === 'whatsapp' ? window.open('', '_blank') : null;   // avoid popup blockers
    try {
      const r = await api('/listings/' + raw.id + '/contact', { method: 'POST', body: JSON.stringify({ channel }) });
      if (channel === 'call') {
        if (r.tel_url) window.location.href = r.tel_url; else toast('This host has no valid phone number on file.');
      } else if (r.whatsapp_url && tab) { tab.opener = null; tab.location = r.whatsapp_url; }
      else { if (tab) tab.close(); toast('This host has no WhatsApp number on file.'); }
    } catch (e) { if (tab) tab.close(); toast(e.message); }
  }

  function openViewing() {
    needAuth(() => {
      const min = new Date(Date.now() + 2 * 3600e3); min.setMinutes(0, 0, 0);
      const local = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
      modal('mkView',
        '<h2 class="modal-title">Request a viewing</h2>' +
        '<p class="modal-sub">The host will confirm or suggest another time. Times are in your local time.</p>' +
        '<div class="form-group"><label>Preferred date &amp; time</label><input id="mkWhen" type="datetime-local" min="' + local(min) + '" value="' + local(min) + '"></div>' +
        '<div class="form-group"><label>Message (optional)</label><textarea id="mkVMsg" maxlength="500" placeholder="Anything the host should know?"></textarea></div>' +
        '<div class="mk-err" id="mkVErr"></div><button class="form-submit" id="mkVGo">Send request</button>');
      $('mkVGo').onclick = async () => {
        const btn = $('mkVGo'); btn.disabled = true; $('mkVErr').textContent = '';
        try {
          await api('/listings/' + raw.id + '/viewing-requests', { method: 'POST', body: JSON.stringify({
            requested_time: new Date($('mkWhen').value).toISOString(), message: $('mkVMsg').value.trim() || null }) });
          closeModal('mkView'); toast('✓ Viewing requested. The host will confirm.');
        } catch (e) { $('mkVErr').textContent = e.message; }
        btn.disabled = false;
      };
      openModal('mkView');
    });
  }

  /* message-host modal: reuse the page's existing form, now with real endpoint */
  window.submitContact = async function () {
    const name = $('contactName').value.trim(), phone = $('contactPhone').value.trim(), msg = $('contactMsg').value.trim();
    if (!name || !phone || !msg) { toast('Please fill in all fields.'); return; }
    const btn = document.querySelector('#contactModal .form-submit'); btn.disabled = true; btn.textContent = 'Sending…';
    try {
      await api('/listings/' + raw.id + '/contact', { method: 'POST', body: JSON.stringify({ channel: 'message', name, phone, message: msg }) });
      window.closeContactModal(); toast('✓ Message sent. The host will be in touch.');
      ['contactName', 'contactPhone', 'contactMsg'].forEach((i) => { $(i).value = ''; });
    } catch (e) { toast(e.message); }
    btn.disabled = false; btn.textContent = 'Send Message';
  };

  /* ── Makao intelligence panel ────────────────────────────────────── */
  const DIMS = [['budget', 'Budget'], ['location', 'Location'], ['property', 'Home type'], ['commute', 'Commute'],
    ['availability', 'Availability'], ['amenities', 'Amenities'], ['trust', 'Trust']];
  const list = (a) => '<ul class="mk-list">' + a.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>';

  function factsHtml(d) {
    const f = freshness(d);
    const total = Number(d.asking_price) + Number(d.service_charge || 0);
    const est = intel && intel.estimated_monthly_cost;
    let cost = '<span>' + kes(d.asking_price) + '</span><small>Advertised rent' +
      (d.service_charge > 0 ? ' + ' + kes(d.service_charge) + ' service charge = ' + kes(total) + '/month' : '') + '</small>';
    if (est) cost += '<small><b style="display:inline;text-transform:none;letter-spacing:0">Estimated real monthly cost: ' + kes(est) +
      '</b> — an estimate including utilities and transport, not a guaranteed cost.</small>';
    let commute = '<span>—</span><small>Add where you work to see an estimate.</small>';
    if (intel && intel.commute_minutes) commute = '<span>About ' + Math.round(intel.commute_minutes) + ' min</span><small>Estimate, not live traffic' +
      (Prefs.get() && Prefs.get().workplace_name ? ' to ' + esc(Prefs.get().workplace_name) : '') + '.</small>';
    return '<div class="mk-grid">' +
      '<div class="mk-stat"><b>Monthly cost</b>' + cost + '</div>' +
      '<div class="mk-stat"><b>Commute</b>' + commute + '</div>' +
      '<div class="mk-stat"><b>Availability</b><span class="mk-' + f.tone + '">' + esc(f.text) + '</span></div>' +
      '<div class="mk-stat"><b>Host</b><span>' + esc(VERIFY[d.host_verification_status] || VERIFY.unverified) + '</span>' +
        '<small>Status set by Makao; details of what was checked are not shown yet.</small></div></div>';
  }

  function askHtml() {
    return '<div class="mk-ask"><div class="mk-h">How well does this fit you?</div>' +
      '<textarea id="mkAskText" maxlength="1000" placeholder="e.g. I work in Upper Hill, earn 80k, need a 1 bedroom under 30k and don\'t drive."></textarea>' +
      '<button class="mk-btn" id="mkAskGo">Check my fit</button><div class="mk-err" id="mkAskErr"></div></div>';
  }

  function fitHtml(r) {
    const s = r.score, e = r.explanation;
    return '<div class="mk-score"><div class="mk-score-num">' + s.overall_score + '%</div>' +
      '<div><div class="mk-h" style="margin:0">Match score</div><div class="mk-note" style="margin:0">' + esc(e.summary || '') + '</div></div></div>' +
      '<div class="mk-bars">' + DIMS.map((d) => '<div class="mk-bar">' + d[1] + ' · ' + s[d[0] + '_score'] +
        '<i><em style="width:' + s[d[0] + '_score'] + '%"></em></i></div>').join('') + '</div>' +
      (e.reasons && e.reasons.length ? '<div class="mk-h">Why this fits you</div>' + list(e.reasons) : '') +
      (e.drawbacks && e.drawbacks.length ? '<div class="mk-h">Potential drawbacks</div>' + list(e.drawbacks) : '') +
      '<div class="mk-note">Scores come from a fixed formula using your answers and the listing’s data. ' +
      (e.source === 'llm' ? 'The wording was tidied by AI; the numbers were not.' : '') +
      ' <button class="mk-link" id="mkReset">Change my answers</button></div>';
  }

  async function renderIntel() {
    const box = $('mkIntelBody'); if (!box || !raw) return;
    const prefs = Prefs.get();
    let html = factsHtml(raw);
    if (!prefs) { box.innerHTML = html + askHtml(); bindAsk(); return; }
    box.innerHTML = html + '<div class="mk-note">Working out your match…</div>';
    try {
      const r = await api('/listings/' + raw.id + '/fit', { method: 'POST', body: JSON.stringify({
        preferences: prefs, estimated_monthly_cost: intel && intel.estimated_monthly_cost || null,
        commute_minutes: intel && intel.commute_minutes || null, use_ai: true }) });
      box.innerHTML = html + fitHtml(r);
      $('mkReset').onclick = () => { Prefs.clear(); intel = null; renderIntel(); };
    } catch (e) {
      Prefs.clear(); box.innerHTML = html + askHtml(); bindAsk();
      $('mkAskErr').textContent = 'Please re-enter what you’re looking for (' + e.message + ').';
    }
  }

  function bindAsk() {
    const go = $('mkAskGo'); if (!go) return;
    go.onclick = async () => {
      const text = $('mkAskText').value.trim(); if (text.length < 3) return;
      go.disabled = true; $('mkAskErr').textContent = '';
      try {
        const r = await api('/ai/extract-preferences', { method: 'POST', body: JSON.stringify({ message: text }) });
        if (!r.ready_to_search) { $('mkAskErr').textContent = r.followup_question; go.disabled = false; return; }
        Prefs.set(r.preferences);
        await loadIntel(raw.id); renderIntel();
      } catch (e) { $('mkAskErr').textContent = e.message; go.disabled = false; }
    };
  }

  /* optional Phase 4 block: only requested when we know the workplace */
  async function loadIntel(id) {
    intel = null;
    const p = Prefs.get();
    if (!p || p.workplace_latitude == null) return;
    const q = new URLSearchParams({ workplace_lat: p.workplace_latitude, workplace_lon: p.workplace_longitude });
    if (p.workplace_name) q.set('workplace_name', p.workplace_name);
    if (p.transport_mode) q.set('transport_mode', p.transport_mode);
    const budget = p.total_housing_budget || p.rent_budget; if (budget) q.set('monthly_budget', budget);
    try { const d = await api('/listings/' + id + '?' + q.toString()); intel = d.intelligence || null; } catch (e) { intel = null; }
  }

  /* ── page wiring ─────────────────────────────────────────────────── */
  function reshapeStaticBlocks(d) {
    // honest badges (replace legacy "Verified Agency"/"Available"/"Featured")
    const f = freshness(d);
    $('listingBadges').innerHTML =
      '<span class="badge badge-avail" style="' + (f.tone === 'good' ? '' : 'background:#fff4e0;color:#b26a00') + '">' + esc(f.text) + '</span>' +
      (d.is_sponsored ? '<span class="mk-spons">Sponsored</span>' : '');
    $('metaLocation').textContent = places(adapt(d));
    $('fullAddress').textContent = (d.property.location && d.property.location.address) || places(adapt(d));
    $('hostSince').textContent = VERIFY[d.host_verification_status] || VERIFY.unverified;
    $('hostBadge').innerHTML = '';
    // booking card
    $('bcDeposit').textContent = d.deposit > 0 ? 'Deposit: ' + kes(d.deposit) : 'Deposit not specified';
    $('bcLocation').textContent = places(adapt(d));
    const av = $('bcAvailBadge');
    av.lastChild.textContent = ' ' + f.text;
    if (f.tone !== 'good') { av.style.background = '#fff4e0'; av.style.color = '#b26a00'; av.querySelector('.bc-avail-dot').style.background = '#b26a00'; }
    const pkg = $('bcPackage'); if (pkg) pkg.closest('.bc-row').style.display = 'none';
    // actions
    document.querySelector('.bc-cta').innerHTML =
      '<div class="mk-actions"><button class="bc-btn-primary" id="mkViewBtn">Request a viewing</button>' +
      '<div class="mk-two"><button class="bc-btn-secondary" id="mkCallBtn">📞 Call</button><button class="bc-btn-secondary" id="mkWaBtn">💬 WhatsApp</button></div>' +
      '<button class="bc-btn-secondary" onclick="openContactModal()">✉️ Message host</button>' +
      '<button class="bc-btn-secondary" onclick="openChatbot()">🤖 Ask AI about this listing</button></div>';
    $('mkViewBtn').onclick = openViewing;
    $('mkCallBtn').onclick = () => contactChannel('call');
    $('mkWaBtn').onclick = () => contactChannel('whatsapp');
    // trust list: only things that are true
    document.querySelector('.bc-trust').innerHTML =
      ['Results are ranked by fit — never by payment.', 'Estimates are labelled and are not guaranteed costs.',
        'Contact the host directly — no commission.'].map((t) =>
        '<div class="trust-item"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' + esc(t) + '</div>').join('');
    // footer: share stays, unsupported "report" link hidden until admin tools ship
    const foot = document.querySelector('.bc-footer');
    foot.innerHTML = '<a href="#" id="mkShareLink">Share on WhatsApp</a>';
    $('mkShareLink').onclick = (e) => { e.preventDefault(); share(); };
  }

  function mountPanel() {
    if ($('mkIntel')) return;
    const anchor = $('descriptionText').closest('.detail-section');
    const sec = document.createElement('div');
    sec.className = 'detail-section'; sec.id = 'mkIntel';
    sec.innerHTML = '<h2 class="detail-section-title">Makao intelligence</h2><div class="mk-intel" id="mkIntelBody"></div>';
    anchor.parentNode.insertBefore(sec, anchor);
  }

  async function load(id) {
    try {
      raw = await api('/listings/' + id);
    } catch (e) {
      window.showError(e.status === 404 ? 'This listing could not be found.' : e.message);
      return;
    }
    propertyId = raw.property.id;
    window.populatePage(adapt(raw));
    reshapeStaticBlocks(raw);
    mountPanel();
    await loadIntel(id);
    renderIntel();
    refreshSaved();
  }

  function init() {
    injectStyles();
    window.loadListing = load;
    window.loadSimilar = function () {                     // no demo data; hide until a real endpoint exists
      const g = $('similarListings'); if (g && g.parentElement) g.parentElement.style.display = 'none';
    };
    window.shareListing = share;
    window.reportListing = function () {};
    ['saveBtn', 'shareBtn'].forEach((id) => { const b = $(id); b.replaceWith(b.cloneNode(true)); });   // drop legacy listeners
    $('saveBtn').addEventListener('click', toggleSave);
    $('shareBtn').addEventListener('click', share);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') ['mkAuth', 'mkView'].forEach(closeModal); });
  }

  window.MakaoPage = { closeModal };
  init();
})();
