"""phase6: viewing_requests + contact_requests

Revision ID: 0004_phase6_viewing_contact
Revises: 0003_phase1_availability_preferences
Create Date: 2026-10-01

viewing_requests  — renter asks to view a property (keyed on property_id AND
                    listing_id per roadmap section 8). One ACTIVE request
                    (requested/confirmed) per renter per listing.
contact_requests  — lead log for call / WhatsApp / message actions. user_id is
                    nullable so anonymous visitors can still contact a host.
Neither table is gated by payment. No existing table is altered.
"""
from alembic import op

revision = "0004_phase6_viewing_contact"
down_revision = "0003_phase1_availability_preferences"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS viewing_requests (
            id             SERIAL PRIMARY KEY,
            user_id        INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            property_id    INTEGER      NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
            listing_id     INTEGER      NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
            host_id        INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            requested_time TIMESTAMPTZ  NOT NULL,
            message        TEXT,
            host_note      TEXT,
            status         VARCHAR(20)  NOT NULL DEFAULT 'requested'
                              CHECK (status IN ('requested','confirmed','completed','cancelled','no_show')),
            created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
            updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_viewing_user    ON viewing_requests(user_id, requested_time DESC);
        CREATE INDEX IF NOT EXISTS idx_viewing_host    ON viewing_requests(host_id, status);
        CREATE INDEX IF NOT EXISTS idx_viewing_listing ON viewing_requests(listing_id);
        CREATE UNIQUE INDEX IF NOT EXISTS uq_viewing_one_active
            ON viewing_requests(user_id, listing_id)
            WHERE status IN ('requested','confirmed');

        DO $$
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_viewing_updated_at') THEN
                CREATE TRIGGER trg_viewing_updated_at
                BEFORE UPDATE ON viewing_requests
                FOR EACH ROW EXECUTE FUNCTION set_updated_at();
            END IF;
        END;
        $$;

        CREATE TABLE IF NOT EXISTS contact_requests (
            id          SERIAL PRIMARY KEY,
            listing_id  INTEGER     NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
            property_id INTEGER     NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
            host_id     INTEGER     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            user_id     INTEGER     REFERENCES users(id) ON DELETE SET NULL,
            channel     VARCHAR(20) NOT NULL CHECK (channel IN ('call','whatsapp','message')),
            name        VARCHAR(120),
            phone       VARCHAR(20),
            message     TEXT,
            created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_contact_host    ON contact_requests(host_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_contact_listing ON contact_requests(listing_id);
        """
    )


def downgrade() -> None:
    op.execute(
        """
        DROP TABLE IF EXISTS contact_requests;
        DROP TABLE IF EXISTS viewing_requests;
        """
    )
